<?php if(is_active_sidebar('main-sidebar')){ ?>
        <aside id="sidebar" class="sidebar">
            <?php  dynamic_sidebar('main-sidebar'); ?>
        </aside>
<?php } ?>