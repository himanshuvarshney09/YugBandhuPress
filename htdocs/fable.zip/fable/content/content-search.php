
<article id="post-<?php the_ID(); ?>" class="result_search">
        <div class="post-title">
	            <?php fable_content_title(); /* Display title of post */ ?>
	    </div>
	    <div class="post-body">
	            <?php fable_content_body(); /* Display content of post or intro in category page */ ?>
	    </div>

</article>
